package lib;

public class AppUtility {

}
