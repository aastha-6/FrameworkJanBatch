package lib;

public class Global {
	
	public static String gstrGroupControlFile = System.getProperty("user.dir") + "\\TestArtifcats\\GroupControlFile.xlsx";

	
	public static String gstrID;
	public static String gstrAutomationID;
	public static String gstrManualID;
	public static String gstrDesrciption;

}
