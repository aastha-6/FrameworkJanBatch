package lib;

import java.util.ArrayList;
import java.util.List;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class Utility {
	
	
	/**
	 * @MethodName getRecordUsingFillo
	 * @param strQuery ,  filePath
	 * @return  Recordset
	 * @author Dharm
	 */
	public static Recordset getRecordUsingFillo(String filePath , String strQuery) {
	
		Fillo f;
		Connection con ;
		Recordset rs =null;		
		try {
			f = new Fillo();
			con = f.getConnection(filePath);
			rs = con.executeQuery(strQuery);
		}
		catch(Exception e) {
			
		}
		return rs;
		
	}
	
	
	/**
	 * @MethodName getRecordUsingFillo
	 * @param strQuery ,  filePath
	 * @return  listGrp
	 * @author Dharm
	 */
	public static List readGroups (String filePath , String strQuery) {
		ArrayList listGrp = new ArrayList();
		Recordset rs = null;
		
		try {
			rs = Utility.getRecordUsingFillo(filePath, strQuery);
			while(rs.next()) {
				String strGrp = rs.getField("Groups");
				listGrp.add(strGrp);
			}
		}
		catch(Exception e) {
			
		}
		return listGrp;
		
	}
	
	
	/**
	 * @MethodName getRecordUsingFillo
	 * @param strQuery ,  filePath
	 * @return  listGrp
	 * @author Dharm
	 */
	
	public static Recordset readTestcases(String strFile , String strQuery) {
		Recordset rs;
		return rs = Utility.getRecordUsingFillo(strFile, strQuery);
	}

}
