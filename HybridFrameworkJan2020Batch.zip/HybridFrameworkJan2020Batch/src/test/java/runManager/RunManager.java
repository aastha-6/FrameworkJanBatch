package runManager;

import java.util.List;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;

import lib.Global;
import lib.Utility;

public class RunManager {

	
	public static void main(String[] args) throws FilloException {
		
		String strQuery = "select * from Groups where Run = 'Y' ";
		List <String> listGroups = Utility.readGroups(Global.gstrGroupControlFile, strQuery);
		
		for(int i=0 ; i<listGroups.size();i++) {
			
			String strGrpName = listGroups.get(i);
			
			String strTestCaseQuery = "select * from " + strGrpName + " where Run = 'Y' ";
			
			Recordset rs_TestCase = Utility.readTestcases(Global.gstrGroupControlFile, strTestCaseQuery);
			if(rs_TestCase!=null) {
				while(rs_TestCase.next()) {
					Global.gstrID = rs_TestCase.getField("ID");
					Global.gstrAutomationID = rs_TestCase.getField("AutomationID");
					Global.gstrManualID = rs_TestCase.getField("ManualTestID");
					Global.gstrDesrciption = rs_TestCase.getField("Description");
					rs_TestCase.getField("Batch");		
				}
			}
			
			
			
			
		}
		
		
	

	}

}
